package Hospitalmanagementsystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HospitalManagentSystem {
	private static final String url = "jdbc:mysql://localhost:3306/hospitalmanagemntsystem";
	private static final String username = "root";
	private static final String password = "Kunal@637";
	public static void main(String[]args) {
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
            Scanner scanner = new Scanner(System.in);		
		try {
			Connection connection = DriverManager.getConnection(url,username,password);
			Patient patient = new Patient(scanner, connection);
			Docter docter = new Docter(connection);
			while(true) {
			   System.out.println("HOSPITAL MANAGEMENT SYSTEM ");
			   System.out.println("1.Add Patient");
			   System.out.println("2.View Patient");
			   System.out.println("3.View Docter");
			   System.out.println("4.Book Appointement");
			   System.out.println("5. Exit");
			   System.out.println("Enter Your choice: ");
			   int choice= scanner.nextInt();
			   
			   switch(choice) {
			   case 1:
				   // Add Patient
				   patient.addPatient();
				   System.out.println();
				   
			   case 2:
				   // view Patient
				   patient.viewPatients();
				   System.out.println();
				   
			   case 3:
				   // view Docter
				   docter.viewDocters();
				   System.out.println();
			   case 4:
				   // book
				   bookAppointment(patient,docter,connection,scanner);
				   System.out.println();
			   case 5:
				  return;
			   default:
				   System.out.println("Enter Valid Choice ");
			}
			}	
		}catch (SQLException e) {
			e.printStackTrace();
		
	
		}
		}
		public static void bookAppointment(Patient patient , Docter docter,Connection connection , Scanner scanner ) {
			System.out.print("Enter Patient Id:");
			int patientId= scanner.nextInt();
			System.out.print("Enter Docter Id:");
			int docterId= scanner.nextInt();
			System.out.print("Enter appointment date (dd/mm/yyyy):");
			int appointmentDate = scanner.nextInt();
		    if(patient.getPatientById(patientId) && docter.getDocterById(docterId)) {
		    	if(checkDocterAvabilability(docterId,appointmentDate, connection)) {
		    		String appointmentdataQuery = "INSERT INTO appointments(patient_id,docter_id ,appointment_date )VALUE(?,?,?)";
		    		try { 
		    		PreparedStatement perparedStatement = connection.prepareStatement(appointmentdataQuery);
		    		perparedStatement.setInt(1,patientId);
		    		perparedStatement.setInt(2,docterId);
		    		perparedStatement.setInt(3,appointmentDate);
		    		int rowAffected = perparedStatement.executeUpdate();
		    		if(rowAffected>0) {
		    			System.out.println("Appointment Booked");
		    			
		    		}else {
		    			System.out.println("Failed to Book Appointment");}
		    	}  catch(SQLException e){
		    			e.printStackTrace();
		    		
		    		}
		    
		    				
		    	}else {
		    		System.out.println("Docter not available on this  date");	
		    	}
		    	
		    	
		    	
	   	
		}else {
			System.out.println("Either docter or patient doesn't exist");
			}
		    
		}
		
		public static boolean checkDocterAvabilability(int docterId, int appointmentDate, Connection connection) {
			String query = "SELECT COUNT(*) FORM  appointments WHERE docter_id=? AND appointment_date =?";
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1,docterId);
				preparedStatement.setLong(2,appointmentDate);
				ResultSet resultSet  = preparedStatement.executeQuery();
				if(resultSet.next()) {
					int count= resultSet.getInt(1);
					if(count==0) {
						return true;
					}else {
						return false;
					}
				}
				} catch(SQLException e) {
					e.printStackTrace();
				}
			return false;
					
						
				}
}
				
					
				
				
				
		
		

		

