package Hospitalmanagementsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Docter {
	 private Connection connection;
	
	 public Docter( Connection connection) {
		 this.connection = connection;
		 
	 }

			 
		 
		  public void viewDocters() {
			  String query = "select * from Docters";
			  try {
				  PreparedStatement preparedStatement = connection.prepareStatement(query);
				  ResultSet resultSet = preparedStatement.executeQuery();
				  System.out.println("Docter:");
				  while(resultSet.next()) {
					  int id = resultSet.getInt("Id");
					  String name =resultSet.getString("Name");
					 String specialization = resultSet.getString("Specialization");
					  System.out.println(id,name,specialization);
					  
				  }
				  
				  
			  }catch(SQLException e) {
				  e.printStackTrace();
				  }
				
			  }
			  public boolean getDocterById(int Id) {
				  String query = "SELECT * FROM Docter WHERE Id=?";
				  try { 
					  PreparedStatement preparedStatement = connection.prepareStatement(query);
					  preparedStatement.setInt(1,Id);
					  ResultSet resultSet = preparedStatement.executeQuery();
					  if(resultSet.next()) {
						  return true;
					  
				  }else
				  {
					  return false;
					  }
				  } catch(SQLException e) {
						  e.printStackTrace();
					  }
				  return false;
			  }
		 
}
