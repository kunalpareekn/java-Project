package Hospitalmanagementsystem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.sql.SQLException;

public class Patient {
 private Connection connection;
 private Scanner scanner;
 public Patient(Scanner scanner, Connection connection) {
	 this.connection = connection;
	 this.scanner = scanner;
 }
 public void addPatient() {
	 System.out.print("Enter Patient Id");
	 int id = scanner.nextInt();
	 System.out.print("Enter Patient Name");
	 String name = scanner.next();
	 System.out.print("Enter Patient Age");
	 int age = scanner.nextInt();
	 System.out.print("Enter Patient Gender");
	 String gender = scanner.next();
	 try {
		  
		 String query ="INSERT INTO patient(Id,Name,Age,Gender)VALUES(?,?,?,?)";
		 PreparedStatement preparedStatement = connection.prepareStatement(query);
		 preparedStatement.setInt(1,id);
		 preparedStatement.setString(2,name);
		 preparedStatement.setInt(3, age);
		 preparedStatement.setString(4, gender);
		 int affectedRows = preparedStatement.executeUpdate();
		 if(affectedRows>0) {
			 System.out.print("Patient Added Successfully");
		 }else {
			 System.out.print("Failed to add Patient");
		 }
		 
		 }catch(SQLException e) {
		 e.printStackTrace();
		 }
		 
	 }
	  public void viewPatients() {
		  String query = "select * from patient";
		  try {
			  PreparedStatement preparedStatement = connection.prepareStatement(query);
			  ResultSet resultSet = preparedStatement.executeQuery();
			  System.out.println("Patients:");
			  while(resultSet.next()) {
				  int id = resultSet.getInt("Id");
				  String name =resultSet.getString("Name");
				  int age = resultSet.getInt("Age");
				  String gender =resultSet.getString("Gender");
				  System.out.println();
				  
			  }
			  
			  
		  }catch(SQLException e) {
			  e.printStackTrace();
			  }
			
		  }
		  public boolean getPatientById(int Id) {
			  String query = "SELECT * FROM patients WHERE Id=?";
			  try { 
				  PreparedStatement preparedStatement = connection.prepareStatement(query);
				  
				preparedStatement.setInt(1,Id);
				  ResultSet resultSet = preparedStatement.executeQuery();
				  if(resultSet.next()) {
					  return true;
				  
			  }else
			  {
				  return false;
				  }
			  } catch(SQLException e) {
					  e.printStackTrace();
				  }
			  return false;
		  }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
 }
 
 
 

